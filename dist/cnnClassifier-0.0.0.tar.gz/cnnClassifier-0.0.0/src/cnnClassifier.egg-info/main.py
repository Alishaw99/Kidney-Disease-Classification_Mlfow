from cnnClassifier import logger


logger.info ("Welcome to the new world of logging")